// server.js
const express = require('express');
const { WebSocketServer } = require('ws');
const http = require('http');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

app.use(express.static(path.join(__dirname, 'public')));

// ---- Game state ----
let clients = new Map(); // ws -> {id, name, bal, bet, auto, halfAuto, placed}
let playersById = {}; // id -> client data (for quick lookup)
let round = 0;
let phase = 'CLOSED'; // CLOSED | BETTING | IN_PLAY | CRASHED
let multiplier = 1.0;
let crashPoint = 1.0;
let tickTimer = null;
let bettingTimer = null;

// Config
const BETTING_SECONDS = 10; // seconds for betting phase
const START_BALANCE = 100000000; // Rp 100.000.000
const RIG_BIAS_AFTER = 5; // after these many rounds bias crashes lower

function broadcast(obj) {
  const msg = JSON.stringify(obj);
  for (const ws of clients.keys()) {
    if (ws.readyState === 1) ws.send(msg);
  }
}

function scheduleCrash(roundNo) {
  if (roundNo <= 2) return +(1.2 + Math.random()*5.0).toFixed(2);
  if (roundNo <= 5) return +(1.05 + Math.random()*1.8).toFixed(2);
  let p = Math.random();
  if (p < 0.75) return +(1.00 + Math.random()*0.6).toFixed(2);
  if (p < 0.95) return +(1.6 + Math.random()*1.6).toFixed(2);
  return +(2.5 + Math.random()*4.0).toFixed(2);
}

function startBettingPhase() {
  phase = 'BETTING';
  round++;
  // reset placed bets for this round marker (we keep bets placed property)
  for (const data of clients.values()) {
    data.placed = false;
    data.betAmount = 0;
    data.cashed = false;
  }
  broadcast({ type: 'phase', phase, round, time: BETTING_SECONDS });
  // after BETTING_SECONDS -> start round
  let secondsLeft = BETTING_SECONDS;
  bettingTimer = setInterval(()=> {
    secondsLeft--;
    broadcast({ type:'bet_timer', secondsLeft });
    if (secondsLeft <= 0) {
      clearInterval(bettingTimer);
      beginRound();
    }
  }, 1000);
}

function beginRound() {
  // collect bets already deducted on place
  phase = 'IN_PLAY';
  multiplier = 1.0;
  crashPoint = scheduleCrash(round);
  broadcast({ type:'phase', phase, round, crashPointPublic: null }); // don't send crashPoint
  // start multiplier tick
  let v = 0.012;
  tickTimer = setInterval(() => {
    v *= 1.013;
    multiplier = +(multiplier + v).toFixed(2);

    // server-side auto / halfAuto checks per player
    for (const [ws, data] of clients.entries()) {
      if (!data.placed || data.cashed) continue;
      // half auto
      if (data.halfAuto && !data.halfCashed && multiplier >= data.halfTarget) {
        const win = Math.floor((data.betAmount/2) * multiplier);
        data.balance += win;
        data.halfCashed = true;
        data.cashed = true; // mark as done for this simple demo
        ws.send(JSON.stringify({ type:'auto_half', win, multiplier }));
      }
      // full auto
      if (data.auto && multiplier >= data.autoTarget && !data.cashed) {
        const win = Math.floor(data.betAmount * multiplier);
        data.balance += win;
        data.cashed = true;
        ws.send(JSON.stringify({ type:'auto_full', win, multiplier }));
      }
    }

    broadcast({ type:'multiplier', multiplier });

    // crash check
    if (multiplier >= crashPoint) {
      clearInterval(tickTimer);
      phase = 'CRASHED';
      // settle those who did not cash (they lose their betAmount already deducted)
      // notify clients and update balances already handled for winners above
      broadcast({ type:'phase', phase, multiplier, crashPoint });
      // after short delay, start next betting
      setTimeout(() => {
        broadcast({ type:'round_result', round, crashPoint });
        // start next betting after 3s
        setTimeout(startBettingPhase, 3000);
      }, 800);
    }
  }, 90);
}

wss.on('connection', (ws) => {
  const id = uuidv4();
  clients.set(ws, { id, name: null, balance: START_BALANCE, betAmount:0, auto:false, autoTarget:2.00, halfAuto:false, halfTarget:1.5, placed:false, cashed:false, halfCashed:false });
  playersById[id] = clients.get(ws);

  // send welcome + current state
  ws.send(JSON.stringify({ type:'welcome', id, phase, round, multiplier, balance:clients.get(ws).balance }));

  ws.on('message', (msg) => {
    let data;
    try { data = JSON.parse(msg); } catch(e){ return; }
    const c = clients.get(ws);
    if (!c) return;

    if (data.type === 'join') {
      c.name = (data.name || 'Guest').slice(0,20);
      // broadcast player list
      broadcastPlayers();
    }

    if (data.type === 'place_bet') {
      if (phase !== 'BETTING') {
        ws.send(JSON.stringify({ type:'error', message:'Betting closed' }));
        return;
      }
      const amount = Number(data.amount) || 0;
      if (amount <= 0 || amount > c.balance) {
        ws.send(JSON.stringify({ type:'error', message:'Invalid bet' }));
        return;
      }
      // deduct immediately
      c.balance -= amount;
      c.betAmount = amount;
      c.placed = true;
      c.cashed = false;
      c.halfCashed = false;
      c.auto = !!data.auto;
      c.autoTarget = Number(data.autoTarget) || c.autoTarget;
      c.halfAuto = !!data.halfAuto;
      c.halfTarget = Number(data.halfTarget) || c.halfTarget;
      ws.send(JSON.stringify({ type:'bet_placed', amount, balance:c.balance }));
      broadcastPlayers();
    }

    if (data.type === 'manual_cashout') {
      // allow manual cashout only in-play
      if (phase !== 'IN_PLAY' || !c.placed || c.cashed) return;
      const win = Math.floor(c.betAmount * multiplier);
      c.balance += win;
      c.cashed = true;
      ws.send(JSON.stringify({ type:'manual_cashout', win, multiplier, balance:c.balance }));
      broadcastPlayers();
    }

    if (data.type === 'get_state') {
      ws.send(JSON.stringify({ type:'state', phase, round, multiplier }));
    }
  });

  ws.on('close', () => {
    const info = clients.get(ws);
    if (info) {
      delete playersById[info.id];
      clients.delete(ws);
      broadcastPlayers();
    }
  });

  // initial broadcast of players
  broadcastPlayers();
});

function broadcastPlayers() {
  const list = Array.from(clients.values()).map(p => ({
    id: p.id, name: p.name || 'Guest', balance: p.balance, bet: p.betAmount || 0, placed: p.placed || false
  }));
  broadcast({ type:'players', players: list });
}

// start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log('Server listening on', PORT);
  // start first betting phase after server up
  setTimeout(startBettingPhase, 1500);
});